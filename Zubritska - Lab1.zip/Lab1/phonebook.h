#ifndef PHONEBOOK_H
#define PHONEBOOK_H

#include "Contact.h"
#include "ContactListRepository.h"
#include <string>

class PhoneBook
{
public:
    PhoneBook(const string file) : clr(new ContactListRepo(file)){};
    ~PhoneBook()
    {
        delete clr;
        if(!filterResults.empty())  for(size_t i = filterResults.size() - 1; i>=0 ; --i) delete filterResults.at(i);
    }

    bool isFiltered();
    bool isEmpty();
    bool isLoaded();

    Contact& contact(const size_t);
    size_t size();

    const Contact& getContact(const size_t);

    void addContact(const Contact&);
    void delContact(const size_t);
    void filter(const QString&);
    void cleanFiltered();
    void quitFilter();

    void loadPhoneBook();
    void savePhoneBook();

private:
    vector<Contact> conList;
    vector<Contact*> filterResults;

    ContactListRepo* clr;

    bool _filtered = false;
    bool _loaded = false;

    PhoneBook(const PhoneBook&);
    PhoneBook& operator=(const PhoneBook&);
};

#endif // PHONEBOOK_H
