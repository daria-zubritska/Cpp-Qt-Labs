#include "phonebook.h"
#include <QRegExp>

bool PhoneBook::isFiltered()
{
    return _filtered;
}

bool PhoneBook::isEmpty()
{
    if(!isFiltered())return conList.empty();
    else return filterResults.empty();
}

bool PhoneBook::isLoaded()
{
    return _loaded;
}

Contact &PhoneBook::contact(const size_t i)
{
    if(!isFiltered())   return conList.operator[](i);
    return *filterResults.operator[](i);
}

size_t PhoneBook::size()
{
    if(!isFiltered())return conList.size();
    else return filterResults.size();
}

const Contact& PhoneBook::getContact(const size_t i)
{
    if(!isFiltered())   return conList.operator[](i);
    return *filterResults.operator[](i);
}

void PhoneBook::addContact(const Contact& c)
{
    conList.push_back(c);
    std::sort(conList.begin(), conList.end());
}

void PhoneBook::delContact(const size_t i)
{
    if(!isFiltered()) conList.erase(conList.begin() + i);
    else
    {
        for(size_t j = 0; j<conList.size(); ++j)
        {
            if(filterResults.at(i) == &conList.at(j))
            {
                filterResults.erase(filterResults.begin() + i);
                conList.erase(conList.begin() + j);
                break;
            }
        }
    }
}

void PhoneBook::filter(const QString& search)
{
    QRegExp reNum("[0-9]*");
    if (reNum.exactMatch(search))
    {
        for(size_t i = 0; i < conList.size(); ++i)
        {
            if(conList.operator[](i).startsByNumber(search))
            {
                filterResults.push_back(&conList.operator[](i));
            }
        }
    }
    else
    {
        for(size_t i = 0; i < conList.size(); ++i)
        {
            if(conList.operator[](i).startsByName(search))
            {
                filterResults.push_back(&conList.operator[](i));
            }
        }
    }



    _filtered = true;
}

void PhoneBook::quitFilter()
{
    filterResults.clear();

    _filtered = false;
}

void PhoneBook::cleanFiltered()
{
    filterResults.clear();
}

void PhoneBook::loadPhoneBook()
{
    if(isLoaded()) return;
    clr->loadContList(conList);
    _loaded = true;
}

void PhoneBook::savePhoneBook()
{
    clr->saveContList(conList);
}
