#ifndef CONTACTLISTREPOSITORY_H
#define CONTACTLISTREPOSITORY_H


#include <QString>
#include "Contact.h"
#include <string>

class ContactListRepo
{
public:

    ContactListRepo(): _path(""){};
    ContactListRepo(const string& file): _path(file){};
    ~ContactListRepo(){};

    void loadContList(vector<Contact>&);
    void saveContList(vector<Contact>&);

private:
string _path;
};

#endif // CONTACTLISTREPOSITORY_H
