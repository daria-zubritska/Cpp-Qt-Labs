#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Contact.h"
#include "ContactListRepository.h"
#include "phonebook.h"
#include <string>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->addButton, SIGNAL(clicked()), this, SLOT(addContact()));
    connect(ui->addNum, SIGNAL(clicked()), this, SLOT(addNum()));
    connect(ui->delButton, SIGNAL(clicked()), this, SLOT(delPush()));
    connect(ui->findButton, SIGNAL(clicked()), this, SLOT(findPush()));
    connect(ui->xButton, SIGNAL(clicked()), this, SLOT(closeFilter()));
    connect(ui->editNameBtn, SIGNAL(clicked()), this, SLOT(editContact()));
    connect(ui->editNumBtn, SIGNAL(clicked()), this, SLOT(editNumber()));
    connect(ui->saveEditBtn, SIGNAL(clicked()), this, SLOT(saveEdited()));
    connect(ui->conView, SIGNAL(currentRowChanged(int)), this, SLOT(choice(int)));
    connect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));
    connect(ui->numDel, SIGNAL(clicked()), this, SLOT(deleteNum()));


    ui->addNum->setVisible(false);
    ui->lineNum->setVisible(false);
    ui->editLine->setVisible(false);
    ui->saveEditBtn->setVisible(false);

}

void MainWindow::closeFilter()
{
    if(!_phonebook->isFiltered()) return;

    _phonebook->quitFilter();

    disconnect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));
    ui->widgView->clear();
    connect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

    disconnect(ui->conView, SIGNAL(currentRowChanged(int)), this, SLOT(choice(int)));

    ui->conView->clear();

    for(size_t i = 0; i < _phonebook->size(); ++i)
    {
        ui->conView->addItem(_phonebook->contact(i).name());
    }

    connect(ui->conView, SIGNAL(currentRowChanged(int)), this, SLOT(choice(int)));

    ui->Name->setText("");

    ui->lineSearch->setText("");

    ui->addButton->setEnabled(true);
    ui->lineName->setEnabled(true);
    ui->xButton->setEnabled(false);
    ui->delButton->setEnabled(false);
    ui->editNameBtn->setEnabled(false);

    ui->addNum->setVisible(false);
    ui->lineNum->setVisible(false);
}

void MainWindow::addContact()
{
    if(ui->lineName->text().isEmpty()) return;

    _phonebook->addContact(Contact(ui->lineName->text()));

    disconnect(ui->conView, SIGNAL(currentRowChanged(int)), this, SLOT(choice(int)));
    ui->conView->clear();
    for(size_t i = 0; i < _phonebook->size(); ++i)
    {
        ui->conView->addItem(_phonebook->contact(i).name());
    }

    connect(ui->conView, SIGNAL(currentRowChanged(int)), this, SLOT(choice(int)));

    disconnect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

    ui->Name->setText("");
    ui->widgView->clear();

    connect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

    ui->lineName->setText("");
    ui->numDel->setEnabled(false);

    ui->addNum->setVisible(false);
    ui->lineNum->setVisible(false);
}

void MainWindow::addNum()
{
    if(ui->lineNum->text().isEmpty()) return;
    QString temp = ui->lineNum->text();
    size_t t = ui->conView->currentRow();
    _phonebook->contact(t).addNum(temp);

    disconnect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

    ui->widgView->clear();
    for(size_t i = 0; i < _phonebook->contact(t).numbersSize(); ++i)
    {
        ui->widgView->addItem(_phonebook->contact(t).number(i));
    }

    connect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

    ui->lineNum->setText("");

    ui->numDel->setEnabled(false);
}

void MainWindow::delPush()
{
    int index = ui->conView->currentRow();
    if(index == -1) return;

    _phonebook->delContact(index);

    ui->conView->takeItem(ui->conView->currentRow());

    disconnect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

    ui->Name->setText("");
    ui->widgView->clear();

    connect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

    if(_phonebook->isEmpty())
    {
        ui->editNameBtn->setEnabled(false);
        ui->editLine->setEnabled(false);
        ui->delButton->setEnabled(false);
    }
    ui->numDel->setEnabled(false);

    ui->addNum->setVisible(false);
    ui->lineNum->setVisible(false);
}

void MainWindow::deleteNum()
{
    int index = ui->widgView->currentRow();
    if(index == -1) return;

    _phonebook->contact(ui->conView->currentRow()).delNum(index);

    ui->widgView->takeItem(ui->widgView->currentRow());

    if(_phonebook->isEmpty())
    {
        ui->editNameBtn->setEnabled(false);
        ui->numDel->setEnabled(false);
    }
}

void MainWindow::findPush()
{
    if(ui->lineSearch->text().isEmpty())
    {
        closeFilter();
        return;
    }

    ui->Name->setText("");
    disconnect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));
    ui->widgView->clear();
    connect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

    ui->xButton->setEnabled(true);

    QString search = ui->lineSearch->text();

    _phonebook->cleanFiltered();

    _phonebook->filter(search);

    disconnect(ui->conView, SIGNAL(currentRowChanged(int)), this, SLOT(choice(int)));
    ui->conView->clear();

    for(size_t i = 0; i < _phonebook->size(); ++i)
    {
        ui->conView->addItem(_phonebook->contact(i).name());
    }

    connect(ui->conView, SIGNAL(currentRowChanged(int)), this, SLOT(choice(int)));

    ui->addButton->setEnabled(false);
    ui->lineName->setEnabled(false);
    ui->delButton->setEnabled(false);
    ui->editNameBtn->setEnabled(false);
    ui->addNum->setVisible(false);
    ui->lineNum->setVisible(false);

}

void MainWindow::choice(int index)
{
        ui->Name->setText(_phonebook->contact(index).name());

        disconnect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

        ui->widgView->clear();

        for(size_t i = 0; i < _phonebook->contact(index).numbersSize(); ++i)
        {
            ui->widgView->addItem(_phonebook->contact(index).number(i));
        }

        connect(ui->widgView, SIGNAL(currentRowChanged(int)), this, SLOT(choicePhone(int)));

        if(!_phonebook->isFiltered())
        {
            ui->addButton->setEnabled(true);
            ui->lineName->setEnabled(true);
        }

        ui->delButton->setEnabled(true);
        ui->numDel->setEnabled(false);
        ui->editNameBtn->setEnabled(true);
        ui->editNumBtn->setEnabled(false);
        ui->lineNum->setVisible(true);
        ui->addNum->setVisible(true);

}

void MainWindow::choicePhone(int)
{
    if(!_phonebook->isFiltered())
    {
        ui->delButton->setEnabled(true);
    }

    ui->numDel->setEnabled(true);
    ui->editNumBtn->setEnabled(true);
}

void MainWindow::editContact()
{
    int index = ui->conView->currentRow();
    if(index == -1) return;

    ui->lineSearch->setEnabled(false);
    ui->conView->setEnabled(false);
    ui->widgView->setEnabled(false);
    ui->addButton->setEnabled(false);
    ui->delButton->setEnabled(false);
    ui->findButton->setEnabled(false);
    ui->saveEditBtn->setEnabled(true);
    ui->editNameBtn->setEnabled(false);
    ui->editNumBtn->setEnabled(false);
    ui->numDel->setEnabled(false);
    ui->lineName->setEnabled(false);

    ui->saveEditBtn->setVisible(true);
    ui->editLine->setVisible(true);
    ui->addNum->setVisible(false);
    ui->lineNum->setVisible(false);

    ui->editLine->setValidator(0);
    ui->editLine->setValidator(new QRegExpValidator(QRegExp("[a-z-A-Z-0-9]*"), ui->editLine));
    ui->editLine->setText(ui->conView->currentItem()->text());
}

void MainWindow::editNumber()
{
    int index = ui->conView->currentRow();
    if(index == -1) return;

    ui->lineSearch->setEnabled(false);
    ui->conView->setEnabled(false);
    ui->widgView->setEnabled(false);
    ui->addButton->setEnabled(false);
    ui->delButton->setEnabled(false);
    ui->findButton->setEnabled(false);
    ui->saveEditBtn->setEnabled(true);
    ui->editNameBtn->setEnabled(false);
    ui->editNumBtn->setEnabled(false);
    ui->numDel->setEnabled(false);
    ui->lineName->setEnabled(false);

    ui->saveEditBtn->setVisible(true);
    ui->editLine->setVisible(true);
    ui->addNum->setVisible(false);
    ui->lineNum->setVisible(false);

    ui->editLine->setValidator(0);
    ui->editLine->setValidator(new QRegExpValidator(QRegExp("[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]"), ui->editLine));
    ui->editLine->setText(ui->widgView->currentItem()->text());
}

void MainWindow::saveEdited()
{
    if(ui->editLine->text().isEmpty()) return;

    ui->lineSearch->setEnabled(true);
    ui->conView->setEnabled(true);
    ui->widgView->setEnabled(true);
    ui->delButton->setEnabled(true);
    ui->findButton->setEnabled(true);
    ui->saveEditBtn->setEnabled(false);
    ui->editNameBtn->setEnabled(true);
    ui->editNumBtn->setEnabled(true);
    ui->lineName->setEnabled(true);

    ui->saveEditBtn->setVisible(false);
    ui->editLine->setVisible(false);
    ui->addNum->setVisible(true);
    ui->lineNum->setVisible(true);

    if(!_phonebook->isFiltered())
    {
        ui->addButton->setEnabled(true);
        ui->lineName->setEnabled(true);
    }


    QString temp = ui->editLine->text();

    QRegExp reNum("[0-9]*");
    if (reNum.exactMatch(temp))
    {
        _phonebook->contact(ui->conView->currentRow()).number(ui->widgView->currentRow()) = temp;
        ui->widgView->currentItem()->setText(temp);

    }
    else
    {
        _phonebook->contact(ui->conView->currentRow()).name() = temp;

        ui->conView->currentItem()->setText(temp);
        ui->Name->setText(temp);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
    delete _phonebook;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    _phonebook->savePhoneBook();
}

void MainWindow::showEvent(QShowEvent* event)
{
    QWidget::showEvent(event);
    if(_phonebook->isLoaded()) return;
    loadPhoneBook();

    ui->lineName->setValidator(new QRegExpValidator(QRegExp("[a-z-A-Z-0-9]*"), ui->lineName));
    ui->lineNum->setValidator(new QRegExpValidator(QRegExp("[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]"), ui->lineNum));
}

void MainWindow::loadPhoneBook()
{

    _phonebook->loadPhoneBook();

    if(_phonebook->isEmpty())
    {
        ui->editNameBtn->setEnabled(false);
        return;
    }

    for(size_t i = 0; i < _phonebook->size(); ++i)
    {
        ui->conView->addItem(_phonebook->contact(i).name());
    }
}
