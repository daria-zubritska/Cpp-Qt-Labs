#include <QString>
#include "Contact.h"
#include <QRegExp>

Contact::Contact(const Contact &c)
{
    *this = c;
}

Contact& Contact::operator=(const Contact& c)
{
    this->_name = c.getName();

    this->_numbers.clear();
    for(size_t i = 0; i < c._numbers.size(); ++i)
    {
        this->_numbers.push_back(c._numbers.operator[](i));
    }

    return *this;
}

QString& Contact::name()
{
    return _name;
}

QString Contact::numbers()
{
    QString res;

    for(size_t i = 0; i < _numbers.size(); ++i)
    {
        res += _numbers.operator[](i) + '\n';
    }

    return res;
}

QString& Contact::number(size_t i)
{
    if(i >= _numbers.size()) return _numbers.operator[](0);
    return _numbers.operator[](i);
}

size_t Contact::numbersSize() const
{
    return _numbers.size();
}

QString Contact::numbersForInfo()
{
    QString res;

    for(size_t i = 0; i < _numbers.size(); ++i)
    {
        res += '&' + _numbers.operator[](i);
    }

    return res;
}

const QString& Contact::getName() const
{
    return _name;
}

const QString& Contact::getNumber(size_t i) const
{
    if(i >= _numbers.size()) return _numbers.operator[](0);
    return _numbers.operator[](i);
}

void Contact::addNum(QString& num)
{
    QRegExp reNum("[0-9]*");
    if (!reNum.exactMatch(num)) return;
    _numbers.push_back(num);
}

void Contact::delNum(size_t i)
{
    if(i >= _numbers.size()) return;
    _numbers.erase(_numbers.begin() + i);
}

vector<QString>& Contact::vecNums()
{
    return _numbers;
}

const QString Contact::info()
{
    return name() + ':' + numbers();
}

const QString Contact::infoForSave()
{
    return name() + numbersForInfo();
}

bool Contact::startsByName(const QString& name)
{
    return this->name().startsWith(name,Qt::CaseInsensitive);
}

bool Contact::startsByNumber(const QString &num)
{
    for(size_t i = 0; i < _numbers.size(); ++i)
    {
        if(_numbers.at(i).startsWith(num)) return true;
    }
    return false;
}

bool Contact::operator<(const Contact& c) const
{
    return this->_name < c._name;
}
