#ifndef CONTACT_H
#define CONTACT_H

#include <QString>
#include <vector>

using namespace std;

class Contact
{
public:

    Contact(const QString& name): _name(name){};
    Contact(const Contact&);
    Contact& operator=(const Contact&);
    ~Contact(){};

    QString& name();
    QString numbers();
    QString& number(size_t);
    size_t numbersSize() const;

    const QString& getName() const;
    const QString& getNumbers() const;
    const QString& getNumber(size_t) const;

    void addNum(QString&);
    void delNum(size_t);

    vector<QString>& vecNums();

    const QString info();
    const QString infoForSave();

    bool equalsByName(const QString&);
    bool equalsByNumber(const QString&);
    bool startsByName(const QString&);
    bool startsByNumber(const QString&);

    bool operator<(const Contact&) const;

private:
    QString numbersForInfo();

    QString _name;
    vector<QString> _numbers;
};


#endif // CONTACT_H
