#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Contact.h"
#include "ContactListRepository.h"
#include "phonebook.h"
#include <string>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void closeEvent(QCloseEvent *event);
    void showEvent(QShowEvent* event);

private:
    Ui::MainWindow *ui;

    PhoneBook* _phonebook = new PhoneBook("C:/Users/repor/Qt/Lab1/phonebook.txt");

    void loadPhoneBook();

private slots:
    void addContact();
    void addNum();
    void delPush();
    void findPush();
    void closeFilter();
    void editContact();
    void editNumber();
    void saveEdited();
    void choice(int);
    void choicePhone(int);
    void deleteNum();

};
#endif // MAINWINDOW_H
