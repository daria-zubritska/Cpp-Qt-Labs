#include <QString>
#include "Contact.h"
#include "ContactListRepository.h"
#include <fstream>
#include <sstream>
#include <string>


void ContactListRepo::loadContList(vector<Contact>& conList)
{
    string myText;

    ifstream MyReadFile(_path);

    while (getline (MyReadFile, myText)) {

        std::stringstream test(myText);
        std::string segment;
        std::vector<std::string> seglist;

        while(std::getline(test, segment, '&'))
        {
           seglist.push_back(segment);
        }

        if(seglist.size() < 1) continue;

        QString name = QString::fromStdString(seglist.operator[](0));

        conList.push_back(Contact(name));

        if(seglist.size() == 1) continue;

        for(size_t i = 1; i < seglist.size(); ++i)
        {
            conList.back().vecNums().push_back(QString::fromStdString(seglist.at(i)));
        }
    }

    MyReadFile.close();
}

void ContactListRepo::saveContList(vector<Contact>& conList)
{
    remove(_path.c_str());

    ofstream MyFile(_path);

    for(size_t i = 0; i < conList.size(); ++i)
    {
        MyFile << conList.operator[](i).infoForSave().toStdString() + '\n';
    }

    MyFile.close();
}
