#include "savewindow.h"
#include "ui_savewindow.h"
#include <QValidator>

SaveWindow::SaveWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SaveWindow)
{
    ui->setupUi(this);

    dirmodel = new QFileSystemModel;
    dirmodel->setFilter(QDir::NoDotAndDotDot | QDir::AllDirs);
    dirmodel->setRootPath("C:\\");
    ui->treeView->setModel(dirmodel);

    connect(this, SIGNAL(okBtnClicked(QString&)), parent, SLOT(save(QString&)));


    ui->lineEdit->setValidator(new QRegExpValidator(QRegExp("[a-z-A-Z-0-9]*"), ui->lineEdit));
}

SaveWindow::~SaveWindow()
{
    delete ui;
    delete dirmodel;
}

void SaveWindow::on_treeView_clicked(const QModelIndex &index)
{
    _path = dirmodel->fileInfo(index).absoluteFilePath();
    ui->label->setText("Path: " + dirmodel->fileInfo(index).absoluteFilePath());
}

void SaveWindow::on_pushButton_clicked()
{
    if(ui->lineEdit->text().isEmpty() || ui->label->text().isEmpty() || !dirmodel->fileInfo(ui->treeView->currentIndex()).isDir()) return;

    _path += "/" + ui->lineEdit->text() + ".txt";

    this->close();
    emit okBtnClicked(_path);
}

void SaveWindow::on_pushButton_2_clicked()
{
    this->close();
}
