#include "loadwindow.h"
#include "ui_loadwindow.h"

LoadWindow::LoadWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoadWindow)
{
    ui->setupUi(this);

    dirmodel = new QFileSystemModel;
    dirmodel->setFilter(QDir::NoDotAndDotDot | QDir::AllEntries);
    dirmodel->setRootPath("C:\\");
    ui->treeView->setModel(dirmodel);

    connect(this, SIGNAL(okBtnClicked(QString&)), parent, SLOT(setLoadPath(QString&)));

}

LoadWindow::~LoadWindow()
{
    delete ui;
    delete dirmodel;
}

void LoadWindow::on_treeView_clicked(const QModelIndex &index)
{
    ui->lineEdit->setText(dirmodel->fileInfo(index).absoluteFilePath());
    _path = dirmodel->fileInfo(index).absoluteFilePath();
}

void LoadWindow::on_pushButton_clicked()
{
    if(ui->lineEdit->text().isEmpty() || !dirmodel->fileInfo(ui->treeView->currentIndex()).isFile()) return;

    this->close();
    emit okBtnClicked(_path);
}

void LoadWindow::on_pushButton_2_clicked()
{
    this->close();
}
