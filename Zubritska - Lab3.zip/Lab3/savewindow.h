#ifndef SAVEWINDOW_H
#define SAVEWINDOW_H

#include <string>
#include <QDialog>
#include <QFileSystemModel>

namespace Ui {
class SaveWindow;
}

class SaveWindow : public QDialog
{
    Q_OBJECT

public:
    explicit SaveWindow(QWidget *parent = nullptr);
    ~SaveWindow();

signals:
    void okBtnClicked(QString&);

private slots:
    void on_treeView_clicked(const QModelIndex&);
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();

private:
    Ui::SaveWindow *ui;
    QFileSystemModel *dirmodel;

    QString _path;
};

#endif // SAVEWINDOW_H
