#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "myfilereader.h"
#include <QFileSystemModel>
#include "loadwindow.h"
#include "savewindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->pushButton, SIGNAL(clicked()), this, SLOT(openLoad()));
    connect(ui->pushButton_2, SIGNAL(clicked()), this, SLOT(openSave()));

    ui->pushButton_2->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete fr;
}

void MainWindow::openLoad()
{
    LoadWindow* lw = new LoadWindow(this);

    Qt::WindowFlags flags = Qt::Dialog;
     lw->setWindowFlags(flags);
     lw->setWindowModality(Qt::ApplicationModal);

     lw->setAttribute(Qt::WA_DeleteOnClose);

     lw->show();
}

void MainWindow::openSave()
{
    SaveWindow* sw = new SaveWindow(this);

    Qt::WindowFlags flags = Qt::Dialog;
     sw->setWindowFlags(flags);
     sw->setWindowModality(Qt::ApplicationModal);

     sw->setAttribute(Qt::WA_DeleteOnClose);

     sw->show();
}

void MainWindow::setLoadPath(QString& path)
{
    ui->label->setText("Chosen file: " + path);
    fr->setF(path);

    ui->pushButton_2->setEnabled(true);
}

void MainWindow::save(QString& path)
{
    fr->setT(path);

    ui->label_2->setText("Processing...");
    fr->redFile();

    ui->label_2->setText("Saved to " + path);
}

