#ifndef LOADWINDOW_H
#define LOADWINDOW_H

#include <string>
#include <QDialog>
#include <QFileSystemModel>

namespace Ui {
class LoadWindow;
}

class LoadWindow : public QDialog
{
    Q_OBJECT

public:
    explicit LoadWindow(QWidget *parent = nullptr);
    ~LoadWindow();

signals:
    void okBtnClicked(QString&);

private slots:
    void on_treeView_clicked(const QModelIndex&);
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();

private:
    Ui::LoadWindow *ui;
    QFileSystemModel *dirmodel;

    QString _path;
};

#endif // LOADWINDOW_H
