#include "myfilereader.h"
#include <QFile>
#include <QTextStream>

void MyFileReader::redFile()
{

    QFile to(_pathT);
    to.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&to);
    QFile in(_pathF);
    in.open(QIODevice::ReadOnly|QIODevice::Text);

    QString ch;

    while(!in.atEnd())
    {
        ch = in.read(1);
        if(ch == '\r') continue;
        if(ch == '\n' || ch == '\t') ch = ' ';
        out << ch;
    }

}

void MyFileReader::setF(const QString& f)
{
    _pathF = f;
}

void MyFileReader::setT(const QString &t)
{
    _pathT = t;
}


