#ifndef MYFILEREADER_H
#define MYFILEREADER_H

#include <QString>

using namespace std;

class MyFileReader
{
public:

    MyFileReader(){};
    ~MyFileReader(){};

    void setF(const QString&);
    void setT(const QString&);

    void redFile();

private:
QString _pathF;
QString _pathT;
};

#endif // MYFILEREADER_H
