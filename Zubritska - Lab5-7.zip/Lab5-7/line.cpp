#include "line.h"

void Line::draw(QPointF newPos)
{
    setLine(0, 0, newPos.x() - previous.x(), newPos.y() - previous.y());
}
