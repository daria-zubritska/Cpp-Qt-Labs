#ifndef LINE_H
#define LINE_H

#include <QGraphicsLineItem>
#include "figure.h"

class Line : public QGraphicsLineItem
{
public:
    Line(QGraphicsItem* parent, QPen& currPen, QPointF& previous) : QGraphicsLineItem(parent)
    {
        this->setPen(currPen);
        this->setPos(previous);
        this->previous = previous;
    };

    void draw(QPointF newPos);

private:
    QPointF previous;
};

#endif // LINE_H
