#include "righttriangle.h"

void RightTriangle::draw(QPointF newPos)
{
    QPoint points[3];
    points[0] = QPoint(previous.x(), newPos.y());
    points[1] = QPoint(previous.x(), previous.y());
    points[2] = QPoint(newPos.toPoint());

    QPolygonF polygon;
    polygon<<points[0]<<points[1]<<points[2];
    this->setPolygon(polygon);
}
