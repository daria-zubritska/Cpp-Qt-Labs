#include "diamond.h"


void Diamond::draw(QPointF newPos)
{
    QPoint points[4];
    points[0] = QPoint(previous.x(), ((previous.y() + newPos.y()) / 2));
    points[1] = QPoint(((previous.x() + newPos.x()) / 2), previous.y());
    points[2] = QPoint(newPos.x(), ((previous.y() + newPos.y()) / 2));
    points[3] = QPoint(((previous.x() + newPos.x()) / 2), newPos.y());

    QPolygonF polygon;
    polygon<<points[0]<<points[1]<<points[2]<<points[3];
    this->setPolygon(polygon);
}
