#include "rectangle.h"

void Rectangle::draw(QPointF newPos)
{
    QPoint points[4];
    points[0] = QPoint(previous.x(), newPos.y());
    points[1] = QPoint(previous.x(), previous.y());
    points[2] = QPoint(newPos.x(), previous.y());
    points[3] = QPoint(newPos.toPoint());

    QPolygonF polygon;
    polygon<<points[0]<<points[1]<<points[2]<<points[3];
    this->setPolygon(polygon);
}
