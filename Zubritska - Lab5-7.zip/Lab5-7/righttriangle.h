#ifndef RIGHTTRIANGLE_H
#define RIGHTTRIANGLE_H

#include "figure.h"

class RightTriangle : public Figure
{
public:
    RightTriangle(QGraphicsItem* parent, QPen& currPen, QPointF& previous) : Figure(parent)
    {
        this->setPen(currPen);
        this->previous = previous;
    };

    void draw(QPointF newPos) override;

private:
    QPointF previous;
};

#endif // RIGHTTRIANGLE_H
