#ifndef DIAMOND_H
#define DIAMOND_H

#include "figure.h"

class Diamond : public Figure
{
public:
    Diamond(QGraphicsItem* parent, QPen& currPen, QPointF& previous) : Figure(parent)
    {
        this->setPen(currPen);
        this->previous = previous;
    };

    void draw(QPointF newPos) override;

private:
    QPointF previous;
};

#endif // DIAMOND_H
