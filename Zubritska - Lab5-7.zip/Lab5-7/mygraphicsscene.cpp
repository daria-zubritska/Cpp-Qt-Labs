#include "mygraphicsscene.h"
#include <QGraphicsPathItem>
#include <QPainterPath>
#include <QGraphicsSceneMouseEvent>
#include <QPointF>
#include <QPainter>
#include <QGraphicsLineItem>

#include "figure.h"
#include "line.h"
#include "circle.h"
#include "rectangle.h"
#include "triangle.h"
#include "righttriangle.h"
#include "diamond.h"

MyGraphicsScene::MyGraphicsScene(qreal x, qreal y, qreal width, qreal height, QObject *parent) : QGraphicsScene(x, y, width, height, parent)
{
    connect(this, SIGNAL(selectionChanged()), this, SLOT(clearSelection()));
}

void MyGraphicsScene::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if(event->buttons() & Qt::LeftButton) {

    currPen.setColor(currColor);

    switch(currAction)
    {
    case free:
    {
        myPath = new QGraphicsPathItem();
        myPath->setPen(currPen);
        previous = event->scenePos();

        QPainterPath p;
        p.moveTo(previous);

        myPath->setPath(p);

        this->addItem(myPath);
    }
    break;
    case eraser:
    {
        myPath = new QGraphicsPathItem();
        myPath->setPen(QPen(Qt::white, currPen.width(), Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        previous = event->scenePos();

        QPainterPath p;
        p.moveTo(previous);

        myPath->setPath(p);

        this->addItem(myPath);
    }
    break;
    default:
    {
        previous = event->scenePos();
    }
        break;
    }
    }
}

void MyGraphicsScene::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    if(event->buttons() & Qt::LeftButton)
    {
        changed = true;

        switch(currAction)
        {
        case eraser:
            if(myPath)
            {
                QPainterPath path = myPath->path();
                previous = event->scenePos();
                path.lineTo(previous);
                myPath->setPath(path);
            }
            break;
        case free:
            if(myPath)
            {
                QPainterPath path = myPath->path();
                previous = event->scenePos();
                path.lineTo(previous);
                myPath->setPath(path);
            }
            break;
        case line:
        {
            if(!lineToDraw){
                lineToDraw = new Line(0, currPen, previous);
                this->addItem(lineToDraw);
            }
            lineToDraw->draw(event->scenePos());
        }
            break;
        case rect:
        {
            if(!polygonToDraw){
                polygonToDraw = new Rectangle(0, currPen, previous);
                if(fill) polygonToDraw->setBrush(filler);
                this->addItem(polygonToDraw);
            }
            polygonToDraw->draw(event->scenePos());
        }
            break;
        case circle:
        {
            if(!circleToDraw){
                circleToDraw = new Circle(0, currPen, previous);
                if(fill) circleToDraw->setBrush(filler);
                this->addItem(circleToDraw);
            }
            circleToDraw->draw(event->scenePos());
        }
            break;
        case triangle:
        {
            if(!polygonToDraw)
            {
                polygonToDraw = new Triangle(0, currPen, previous);
                if(fill) polygonToDraw->setBrush(filler);
                this->addItem(polygonToDraw);
            }
            polygonToDraw->draw(event->scenePos());
        }
            break;
        case rightTri:
        {
            if(!polygonToDraw)
            {
                polygonToDraw = new RightTriangle(0, currPen, previous);
                if(fill) polygonToDraw->setBrush(filler);
                this->addItem(polygonToDraw);
            }
            polygonToDraw->draw(event->scenePos());
        }
            break;
        case diamond:
        {
            if(!polygonToDraw)
            {
                polygonToDraw = new Diamond(0, currPen, previous);
                if(fill) polygonToDraw->setBrush(filler);
                this->addItem(polygonToDraw);
            }
            polygonToDraw->draw(event->scenePos());
        }
            break;
        }

    }
}

void MyGraphicsScene::mouseReleaseEvent(QGraphicsSceneMouseEvent*)
{
    switch(currAction)
    {
    case eraser:
    {
        myPath = 0;
    }
        break;
    case free:
    {
        myPath = 0;
    }
        break;

    case line:
    {
        lineToDraw = 0;
    }
        break;
    case circle:
    {
        circleToDraw = 0;
    }
        break;
    default:
    {
        polygonToDraw = 0;
    }
        break;
    }
}

void MyGraphicsScene::setAction(const action a)
{
    currAction = a;
}

void MyGraphicsScene::setColor(QColor color)
{
    currPen.setColor(color);
    currColor = color;
}

void MyGraphicsScene::setWidth(int width)
{
    currPen.setWidth(width);
}

bool MyGraphicsScene::isChanged()
{
    return changed;
}

void MyGraphicsScene::setChanged(bool ch)
{
    changed = ch;
}

void MyGraphicsScene::setBrush(Qt::PenStyle style)
{
    currPen.setStyle(style);
}

QColor MyGraphicsScene::getColor()
{
    return currColor;
}

void MyGraphicsScene::setFill(bool f)
{
    fill = f;
}

void MyGraphicsScene::setFillColor(QColor color)
{
    filler.setColor(color);
}
