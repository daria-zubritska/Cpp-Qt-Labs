#ifndef FIGURE_H
#define FIGURE_H

#include <QGraphicsPolygonItem>

class Figure : public QGraphicsPolygonItem
{
public:
    Figure(QGraphicsItem* parent) : QGraphicsPolygonItem(parent){};
    virtual ~Figure(){};

    virtual void draw(QPointF) = 0;
};

#endif // FIGURE_H
