#include "circle.h"


void Circle::draw(QPointF newPos)
{
    this->setRect(0,0, newPos.x() - previous.x(), newPos.y() - previous.y());
}
