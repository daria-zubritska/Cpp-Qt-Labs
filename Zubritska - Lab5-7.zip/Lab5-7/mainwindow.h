#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsView>
#include "mygraphicsscene.h"
#include <QActionGroup>
#include <QSpinBox>
#include <QCheckBox>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    //void resizeEvent(QResizeEvent*) override;

private slots:
    void update(QAction*);
    void brushUpdate(QAction*);
    void setFiller(int);
    void openColorDialog();
    void openColorDialogFiller();
    void setWidth(int);
    void save();
    void clear();
    void loadImg();
    void exit();

private:

    void setupMenu();
    void setupActions();
    void setupToolbar();
    int openDialog();
    void resizeImg(QImage *image, const QSize &newSize);

    Ui::MainWindow *ui;

    MyGraphicsScene *scene;
    QGraphicsView *view;

    QImage image;

    QMenu *fileMenu;
    QToolBar *editToolBar;
    QActionGroup *shapeActions;
    QActionGroup *brushActions;

    QAction *exitAction;
    QAction *clearAction;
    QAction *eraserAction;
    QAction *freeAction;
    QAction *lineAction;
    QAction *rectAction;
    QAction *circleAction;
    QAction *triangleAction;
    QAction *diamondAction;
    QAction *rightTriAction;

    QAction *paletteAction;
    QAction *fillerPaletteAction;
    QAction *brushAction;
    QAction *dashAction;
    QSpinBox *widInp;
    QCheckBox *fill;

    QAction *openAction;
    QAction *saveAction;

    bool isSaved = true;
};
#endif // MAINWINDOW_H
