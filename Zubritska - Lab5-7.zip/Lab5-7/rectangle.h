#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "figure.h"

class Rectangle : public Figure
{
public:
    Rectangle(QGraphicsItem* parent, QPen& currPen, QPointF& previous) : Figure(parent)
    {
        this->setPen(currPen);
        this->previous = previous;
    };

    void draw(QPointF newPos) override;

private:
    QPointF previous;
};

#endif // RECTANGLE_H
