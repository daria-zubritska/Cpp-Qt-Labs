#include "triangle.h"

void Triangle::draw(QPointF newPos)
{
    QPoint points[3];
    points[0] = QPoint(previous.x(), newPos.y());
    points[1] = QPoint(((previous.x() + newPos.x()) / 2), previous.y());
    points[2] = QPoint(newPos.toPoint());

    QPolygonF polygon;
    polygon<<points[0]<<points[1]<<points[2];
    this->setPolygon(polygon);
}
