#ifndef MYGRAPHICSSCENE_H
#define MYGRAPHICSSCENE_H


#include <QGraphicsScene>
#include <QPainter>

#include "figure.h"
#include "line.h"
#include "circle.h"
#include "rectangle.h"
#include "triangle.h"
#include "righttriangle.h"
#include "diamond.h"


class MyGraphicsScene : public QGraphicsScene
{
public:
    enum action {eraser, free, line, rect, circle, triangle, rightTri, diamond};

    MyGraphicsScene(qreal x, qreal y, qreal width, qreal height, QObject *parent = nullptr);

    void setAction(const action a);
    void setColor(QColor);
    void setWidth(int);
    void setBrush(Qt::PenStyle);
    void setFill(bool);
    void setFillColor(QColor);
    void setChanged(bool);
    bool isChanged();

    QColor getColor();

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *) override;

private:
    QGraphicsPathItem *myPath = 0;
    QPointF previous;
    Line* lineToDraw = 0;
    Circle* circleToDraw = 0;
    Figure *polygonToDraw = 0;
    QPainter painter;

    action currAction = free;
    QPen currPen = QPen(Qt::black, 1, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    QColor currColor = Qt::black;
    QBrush filler = QBrush(Qt::black);

    bool changed = false;
    bool fill = false;
};

Q_DECLARE_METATYPE(MyGraphicsScene::action);

#endif // MYGRAPHICSSCENE_H
