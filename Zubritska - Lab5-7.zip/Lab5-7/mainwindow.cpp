#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "mygraphicsscene.h"
#include <QToolBar>
#include <QColorDialog>
#include <QSpinBox>
#include <QLabel>
#include <QFileDialog>
#include <QGraphicsPixmapItem>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    scene = new MyGraphicsScene(0, 0, this->width(), this->height());

    QMainWindow::showFullScreen();

    view = new QGraphicsView;
    view->setScene(scene);
    view->setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing);
    view->setContextMenuPolicy(Qt::ActionsContextMenu);
    setCentralWidget(view);

    view->setFrameStyle(QFrame::NoFrame);
    view->setAlignment(Qt::AlignTop | Qt::AlignLeft);

    setupActions();
    setupMenu();
    setupToolbar();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupMenu()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(exitAction);

    fileMenu->addSeparator();

    fileMenu->addAction(saveAction);
    fileMenu->addAction(openAction);

    fileMenu->addSeparator();

    fileMenu->addAction(clearAction);
}

void MainWindow::setupActions()
{
    exitAction = new QAction(tr("E&xit"), this);
    exitAction->setShortcut(tr("Ctrl+Q"));
    connect(exitAction, SIGNAL(triggered()), this, SLOT(exit()));

    clearAction = new QAction(tr("Clear"), this);
    clearAction->setShortcut(tr("Ctrl+R"));
    connect(clearAction, SIGNAL(triggered()), this, SLOT(clear()));

    shapeActions = new QActionGroup(this);
    brushActions = new QActionGroup(this);

    eraserAction = new QAction(tr("Eraser"), shapeActions);
    eraserAction->setToolTip("Select to erase drawings.");
    eraserAction->setIcon(QIcon(":/images/eraser.png"));
    QVariant eraser = QVariant::fromValue(MyGraphicsScene::action::eraser);
    eraserAction->setData(eraser);
    eraserAction->setCheckable(true);

    freeAction = new QAction(tr("Free hand"), shapeActions);
    freeAction->setToolTip("Select to freely draw whatever you want.");
    freeAction->setIcon(QIcon(":/images/shape+free.png"));
    QVariant free = QVariant::fromValue(MyGraphicsScene::action::free);
    freeAction->setData(free);
    freeAction->setCheckable(true);
    freeAction->setChecked(true);

    lineAction = new QAction(tr("Line"), shapeActions);
    lineAction->setToolTip("Select to draw straight lines by clicking and then draging your mouse.");
    lineAction->setIcon(QIcon(":/images/shape+strline.png"));
    QVariant line = QVariant::fromValue(MyGraphicsScene::action::line);
    lineAction->setData(line);
    lineAction->setCheckable(true);

    rectAction = new QAction(tr("Rectangle"), shapeActions);
    rectAction->setToolTip("Select to draw rectangles by clicking and then draging your mouse.");
    rectAction->setIcon(QIcon(":/images/shape+rectangle.png"));
    QVariant rect = QVariant::fromValue(MyGraphicsScene::action::rect);
    rectAction->setData(rect);
    rectAction->setCheckable(true);

    circleAction = new QAction(tr("Circle"), shapeActions);
    circleAction->setToolTip("Select to draw elipse by clicking and then draging your mouse.");
    circleAction->setIcon(QIcon(":/images/shape+circle.png"));
    QVariant circle = QVariant::fromValue(MyGraphicsScene::action::circle);
    circleAction->setData(circle);
    circleAction->setCheckable(true);

    triangleAction = new QAction(tr("Triangle"), shapeActions);
    triangleAction->setToolTip("Select to draw triangle by clicking and then draging your mouse.");
    triangleAction->setIcon(QIcon(":/images/triangle.png"));
    QVariant triangle = QVariant::fromValue(MyGraphicsScene::action::triangle);
    triangleAction->setData(triangle);
    triangleAction->setCheckable(true);

    rightTriAction = new QAction(tr("Right triangle"), shapeActions);
    rightTriAction->setToolTip("Select to draw right triangle by clicking and then draging your mouse.");
    rightTriAction->setIcon(QIcon(":/images/right+triangle.png"));
    QVariant rightTri = QVariant::fromValue(MyGraphicsScene::action::rightTri);
    rightTriAction->setData(rightTri);
    rightTriAction->setCheckable(true);

    diamondAction = new QAction(tr("Diamond"), shapeActions);
    diamondAction->setToolTip("Select to draw diamond by clicking and then draging your mouse.");
    diamondAction->setIcon(QIcon(":/images/diamond.png"));
    QVariant diamond = QVariant::fromValue(MyGraphicsScene::action::diamond);
    diamondAction->setData(diamond);
    diamondAction->setCheckable(true);

    connect(shapeActions, SIGNAL(triggered(QAction*)), this, SLOT(update(QAction*)));

    brushAction = new QAction(tr("Brush"), brushActions);
    brushAction->setIcon(QIcon(":/images/brush.png"));
    QVariant brush = QVariant::fromValue(Qt::SolidLine);
    brushAction->setData(brush);
    brushAction->setCheckable(true);
    brushAction->setChecked(true);

    dashAction = new QAction(tr("Dashed brush"), brushActions);
    dashAction->setIcon(QIcon(":/images/dash.png"));
    QVariant dash = QVariant::fromValue(Qt::DashLine);
    dashAction->setData(dash);
    dashAction->setCheckable(true);

    connect(brushActions, SIGNAL(triggered(QAction*)), this, SLOT(brushUpdate(QAction*)));

    paletteAction = new QAction(tr("Palette"), this);
    QPixmap p = QPixmap(200, 200);
    p.fill(QColor(Qt::black));
    paletteAction->setIcon(QIcon(p));
    connect(paletteAction, SIGNAL(triggered()), this, SLOT(openColorDialog()));

    fillerPaletteAction = new QAction(tr("Fill palette"), this);
    fillerPaletteAction->setToolTip("Click to choose filler color.");
    fillerPaletteAction->setIcon(QIcon(p));
    connect(fillerPaletteAction, SIGNAL(triggered()), this, SLOT(openColorDialogFiller()));

    widInp = new QSpinBox(this);
    widInp->setMinimum(1);
    widInp->setMaximum(72);
    widInp->setSingleStep(1);
    widInp->setValue(1);
    widInp->setToolTip("Change pen`s width by writing number or using arrows.");
    connect(widInp, SIGNAL(valueChanged(int)), this, SLOT(setWidth(int)));

    fill = new QCheckBox(this);
    fill->setText("Fill");
    fill->setToolTip("Check to draw filled shapes");
    connect(fill, SIGNAL(stateChanged(int)), this, SLOT(setFiller(int)));

    openAction = new QAction(tr("Load"), this);
    openAction->setShortcut(tr("Ctrl+O"));
    openAction->setToolTip("Open image.");
    openAction->setIcon(QIcon(":/images/open+folders.png"));
    connect(openAction, SIGNAL(triggered()), this, SLOT(loadImg()));

    saveAction = new QAction(tr("Save as"), this);
    saveAction->setShortcut(tr("Ctrl+S"));
    saveAction->setToolTip("Save image.");
    saveAction->setIcon(QIcon(":/images/save+icon.png"));
    connect(saveAction, SIGNAL(triggered()), this, SLOT(save()));
}

void MainWindow::setupToolbar()
{
    editToolBar = addToolBar(tr("Edit"));
    editToolBar->setStyleSheet("font: 12px");

    editToolBar->addAction(saveAction);
    editToolBar->addAction(openAction);

    editToolBar->addSeparator();

    editToolBar->addAction(eraserAction);
    editToolBar->addAction(freeAction);
    editToolBar->addAction(lineAction);
    editToolBar->addAction(rectAction);
    editToolBar->addAction(circleAction);
    editToolBar->addAction(triangleAction);
    editToolBar->addAction(rightTriAction);
    editToolBar->addAction(diamondAction);

    editToolBar->addSeparator();

    editToolBar->addAction(brushAction);
    editToolBar->addAction(dashAction);

    editToolBar->addSeparator();

    editToolBar->addAction(paletteAction);
    editToolBar->addAction(fillerPaletteAction);
    editToolBar->addWidget(fill);

    editToolBar->addSeparator();

    editToolBar->addWidget(new QLabel("Width:"));
    editToolBar->addWidget(widInp);

}

void MainWindow::update(QAction* action)
{
    scene->setAction(qvariant_cast<MyGraphicsScene::action>(action->data()));
}

void MainWindow::save()
{
    const QImage saveDrawing = view->grab().toImage();
    QString filePath = QFileDialog::getSaveFileName(this, "Save Image", "", "PNG (*.png);;JPEG (*.jpg *.jpeg);;BMP (*.bmp)");

    if(filePath != "")
    {
        saveDrawing.save(filePath);
        scene->setChanged(false);
    }

}

void MainWindow::openColorDialog()
{
    QColor customColor = QColorDialog::getColor(Qt::black, this, QString("Pick a pen color"), QColorDialog::ShowAlphaChannel);
    scene->setColor(customColor);

    QPixmap p = QPixmap(200, 200);
    p.fill(QColor(customColor));
    paletteAction->setIcon(QIcon(p));
}

void MainWindow::openColorDialogFiller()
{
    QColor customColor = QColorDialog::getColor(Qt::black, this, QString("Pick a pen color"), QColorDialog::ShowAlphaChannel);
    scene->setFillColor(customColor);

    QPixmap p = QPixmap(200, 200);
    p.fill(QColor(customColor));
    fillerPaletteAction->setIcon(QIcon(p));
}

int MainWindow::openDialog()
{
    QMessageBox dialog(QMessageBox::Question, tr("PaintQT"), tr("Do you want to save changes?"), QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel, this);
    dialog.setButtonText(QMessageBox::Yes, tr("Yes"));
    dialog.setButtonText(QMessageBox::No, tr("No"));
    dialog.setButtonText(QMessageBox::Cancel, tr("Cancel"));
    dialog.setDefaultButton(QMessageBox::Yes);

    return dialog.exec();
}

void MainWindow::setWidth(int width)
{
    scene->setWidth(width);
}

void MainWindow::exit()
{
    if(scene->isChanged())
    {
        int dialog = openDialog();
        if(dialog == QMessageBox::Yes)
        {
            save();
            QApplication::quit();
        }
        else if(dialog == QMessageBox::No)
        {
            QApplication::quit();
        }
        else if(dialog == QMessageBox::Cancel)
        {
            return;
        }
    }
    else
    {
        QApplication::quit();
    }
}

void MainWindow::loadImg()
{
    if(scene->isChanged())
    {
        int dialog = openDialog();
        if(dialog == QMessageBox::Yes)
        {
            save();
            QString openImageLocation = QFileDialog::getOpenFileName(this, tr("Open image"), "", tr("PNG (*.png);;JPEG (*.jpg *.jpeg);;BMP (*.bmp)" ));

            if(openImageLocation != "")
            {
                scene->clear();
                QImage img(openImageLocation);
                QGraphicsPixmapItem* item = new QGraphicsPixmapItem(QPixmap::fromImage(img));
                scene->addItem(item);
            }
        }
        else if(dialog == QMessageBox::No)
        {
            QString openImageLocation = QFileDialog::getOpenFileName(this, tr("Open image"), "", tr("PNG (*.png);;JPEG (*.jpg *.jpeg);;BMP (*.bmp)" ));
            if(openImageLocation != "")
            {
                scene->clear();
                QImage img(openImageLocation);
                QGraphicsPixmapItem* item = new QGraphicsPixmapItem(QPixmap::fromImage(img));
                scene->addItem(item);
            }
        }
        else if(dialog == QMessageBox::Cancel)
        {
            return;
        }
    }
    else
    {
        QString openImageLocation = QFileDialog::getOpenFileName(this, tr("Open image"), "", tr("PNG (*.png);;JPEG (*.jpg *.jpeg);;BMP (*.bmp)" ));
        if(openImageLocation != "")
        {
            scene->clear();
            QImage img(openImageLocation);
            QGraphicsPixmapItem* item = new QGraphicsPixmapItem(QPixmap::fromImage(img));
            scene->addItem(item);
        }
    }


}

void MainWindow::clear()
{
    int dialog = openDialog();
    if(dialog == QMessageBox::Yes)
    {
        save();
        scene->clear();

    }
    else if(dialog == QMessageBox::No)
    {
        scene->clear();
    }
    else if(dialog == QMessageBox::Cancel)
    {
        return;
    }
}

void MainWindow::brushUpdate(QAction* action)
{
    scene->setBrush(qvariant_cast<Qt::PenStyle>(action->data()));
}

void MainWindow::setFiller(int state)
{
    if(state == Qt::Checked) scene->setFill(true);
    else if(state == Qt::Unchecked) scene->setFill(false);
}
