#ifndef CIRCLE_H
#define CIRCLE_H

#include <QGraphicsEllipseItem>

class Circle : public QGraphicsEllipseItem
{
public:
    Circle(QGraphicsItem* parent, QPen& currPen, QPointF& previous): QGraphicsEllipseItem(parent)
    {
        this->setPen(currPen);
        this->setPos(previous);
        this->previous = previous;
    };

    void draw(QPointF);

private:

    QPointF previous;
};

#endif // CIRCLE_H
