#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "figure.h"

class Triangle : public Figure
{
public:
    Triangle(QGraphicsItem* parent, QPen& currPen, QPointF& previous) : Figure(parent)
    {
        this->setPen(currPen);
        this->previous = previous;
    };

    void draw(QPointF newPos) override;

private:
    QPointF previous;
};

#endif // TRIANGLE_H
