#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDragEnterEvent>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->listWidget, SIGNAL(itemClicked(QListWidgetItem *)), this, SLOT(choiceFirst(QListWidgetItem *)));
    connect(ui->listWidget_2, SIGNAL(itemClicked(QListWidgetItem *)), this, SLOT(choiceSecond(QListWidgetItem *)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::choiceFirst(QListWidgetItem *i)
{
    bool ok;
    i->data(Qt::UserRole).toInt(&ok);
    if(ok) ui->label->setText(i->data(Qt::UserRole).toString());
    else ui->label->setText("");
}

void MainWindow::choiceSecond(QListWidgetItem *i)
{
    bool ok;
    i->data(Qt::UserRole).toInt(&ok);
    if(ok) ui->label->setText(i->data(Qt::UserRole).toString());
    else ui->label->setText("");
}
