#include "mylistwidget.h"
#include <QDragMoveEvent>
#include <QMimeData>
#include <QDrag>

MyListWidget::MyListWidget(QWidget *parent) : QListWidget(parent)
{
    this->setIconSize(QSize(55, 55));
    this->setSelectionMode(QAbstractItemView::SingleSelection);
    this->setDragEnabled(true);
    this->setDefaultDropAction(Qt::MoveAction);
    this->setAcceptDrops(true);
    this->setDropIndicatorShown(true);
}

MyListWidget::~MyListWidget() {}

void MyListWidget::dragMoveEvent(QDragMoveEvent* e)
{
    if (e->mimeData()->hasFormat("application/x-item") && e->source() != this)
    {
        e->setDropAction(Qt::MoveAction);
        e->accept();

    } else e->ignore();
}

void MyListWidget::dropEvent(QDropEvent* event)
{
    if (event->mimeData()->hasFormat("application/x-item"))
    {
        event->accept();
        event->setDropAction(Qt::MoveAction);

        QListWidgetItem *item = new QListWidgetItem;
        //QString name = event->mimeData()->data("application/x-item");
        QString name = event->mimeData()->text();

        item->setText(name);
        item->setIcon(QIcon(":/images/iString"));
        item->setData(Qt::UserRole, event->mimeData()->data("application/x-item"));

        addItem(item);

    } else
        event->ignore();
}

void MyListWidget::startDrag(Qt::DropActions supportedActions)
{
    QListWidgetItem* item = currentItem();
    QMimeData* mimeData = new QMimeData;
    QByteArray ba;

    QString textData = item->text() + '!';

    bool ok;
    item->data(Qt::UserRole).toInt(&ok);

    if(!ok) item->setData(Qt::UserRole, "1");
    else item->setData(Qt::UserRole, QString::number(item->data(Qt::UserRole).toInt() + 1));

    ba = item->data(Qt::UserRole).toByteArray();
    mimeData->setData("application/x-item", ba);

    mimeData->setText(textData);

    QDrag* drag = new QDrag(this);

    drag->setMimeData(mimeData);

    if (drag->exec(Qt::MoveAction) == Qt::MoveAction) {
        delete takeItem(row(item));
    }
}

void MyListWidget::dragEnterEvent(QDragEnterEvent* event)
{
    if (event->mimeData()->hasFormat("application/x-item")) event->accept();
    else event->ignore();
}

